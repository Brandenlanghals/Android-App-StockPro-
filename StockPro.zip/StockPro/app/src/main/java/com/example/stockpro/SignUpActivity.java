package com.example.stockpro;


import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.text.TextUtils;
import androidx.appcompat.app.AppCompatActivity;


public class SignUpActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private EditText confirmPasswordEditText;
    private EditText phoneNumberEditText;
    private Button signUpButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        confirmPasswordEditText = findViewById(R.id.confirmPasswordEditText);
        phoneNumberEditText = findViewById(R.id.phoneNumberEditText);
        signUpButton = findViewById(R.id.signUpButton);

        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();
                String confirmPassword = confirmPasswordEditText.getText().toString();
                String phoneNumber = phoneNumberEditText.getText().toString();

                // Validate the input
                if (isValidInput(username, password, confirmPassword, phoneNumber)) {
                    // Save the new user to the database
                    saveUserToDatabase(username, password, phoneNumber);

                    // Navigate back to LoginActivity
                    Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
                    startActivity(intent);
                    finish(); // Optional: Finish the SignUpActivity so that it's not accessible by pressing back
                } else {
                    // Display validation error message
                    Toast.makeText(SignUpActivity.this, "Invalid input", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isValidInput(String username, String password, String confirmPassword, String phoneNumber) {
        // Perform validation on the input
        return !TextUtils.isEmpty(username) && !TextUtils.isEmpty(password)
                && !TextUtils.isEmpty(confirmPassword) && !TextUtils.isEmpty(phoneNumber)
                && password.equals(confirmPassword);
    }

    private void saveUserToDatabase(String username, String password, String phoneNumber) {
        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        long userId = -1;

        try (SQLiteDatabase db = databaseHelper.getWritableDatabase()) {
            ContentValues values = new ContentValues();
            values.put(DatabaseHelper.COLUMN_USERNAME, username);
            values.put(DatabaseHelper.COLUMN_PASSWORD, password);
            values.put(DatabaseHelper.COLUMN_PHONE_NUMBER, phoneNumber);
            userId = db.insert(DatabaseHelper.TABLE_USERS, null, values);
        }

        if (userId != -1) {
            Toast.makeText(SignUpActivity.this, "Account created successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(SignUpActivity.this, "Failed to create an account", Toast.LENGTH_SHORT).show();
        }
    }
}
