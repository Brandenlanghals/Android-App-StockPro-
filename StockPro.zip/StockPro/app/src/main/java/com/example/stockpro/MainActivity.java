package com.example.stockpro;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;
import androidx.annotation.NonNull;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private GridView gridView;
    private DatabaseHelper databaseHelper;
    private EditText editTextAddNew;
    private Button buttonAdd;
    private ItemAdapter adapter;
    private List<Item> items;

    private static final int SMS_PERMISSION_REQUEST_CODE = 1;
    private boolean hasSmsPermission = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView = findViewById(R.id.gridView);
        databaseHelper = new DatabaseHelper(this);
        editTextAddNew = findViewById(R.id.editTextAddNew);
        buttonAdd = findViewById(R.id.buttonAdd);

        // Retrieve data from the database and populate the GridView
        items = databaseHelper.getAllItems(null);
        adapter = new ItemAdapter(this, items);
        gridView.setAdapter(adapter);

        // Set OnClickListener for the Add button
        Button addButton = findViewById(R.id.buttonAdd);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newItemName = editTextAddNew.getText().toString().trim();
                if (!newItemName.isEmpty()) {
                    // Create a new item with default id and quantity of 0
                    Item newItem = new Item(0, newItemName, 0, null);
                    long itemId = databaseHelper.insertItem(newItem);
                    if (itemId != -1) {
                        // Item added successfully, update the GridView
                        newItem.setId((int) itemId);
                        items.add(newItem); // Add the new item to the list
                        adapter.notifyDataSetChanged(); // Notify the adapter of the data change
                        editTextAddNew.setText("");
                        Toast.makeText(MainActivity.this, "Item added successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Failed to add item", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Please enter item name", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set OnClickListener for the Search button
        Button searchButton = findViewById(R.id.buttonSearch);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText searchEditText = findViewById(R.id.editTextSearch); // Update with the correct search bar id
                String searchQuery = searchEditText.getText().toString().trim();
                if (!searchQuery.isEmpty()) {
                    List<Item> searchResults = databaseHelper.searchItemsByName(searchQuery);
                    if (!searchResults.isEmpty()) {
                        // Update the GridView with search results
                        adapter.setItems(searchResults);
                        adapter.notifyDataSetChanged();
                        Toast.makeText(MainActivity.this, "Search results: " + searchResults.size(), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "No matching items found", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Please enter a search query", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set OnItemClickListener for the GridView
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Get the clicked item from the adapter
                Item clickedItem = (Item) parent.getItemAtPosition(position);

                // Open a dialog to edit the quantity of the clicked item
                showEditQuantityDialog(clickedItem);
            }
        });

        // Find the buttons in the footer menu
        Button homeButton = findViewById(R.id.buttonHome);
        Button scanButton = findViewById(R.id.buttonScanFooter);
        Button logoutButton = findViewById(R.id.buttonLogout);

        // Set OnClickListener for the Home button
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the Main screen
                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // Set OnClickListener for the Scan button
        scanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the Scan screen
                Intent intent = new Intent(MainActivity.this, ScanActivity.class);
                startActivity(intent);
            }
        });

        // Set OnClickListener for the Logout button
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Perform logout logic here
                logoutUser();
            }
        });

        // Check if SMS permission is granted
        if (!checkSmsPermission()) {
            // Request SMS permission
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        } else {
            // SMS permission already granted
            hasSmsPermission = true;
        }
    }

    // Method to handle logout functionality
    private void logoutUser() {
        // Perform any necessary cleanup or logout tasks here

        // Navigate to the Login screen
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish(); // Close the current activity to prevent going back to it
    }

    private void showEditQuantityDialog(final Item item) {
        if (isFinishing()) {
            return; // Don't show the dialog if the activity is finishing
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Quantity");

        // Set up the input
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setText(String.valueOf(item.getQuantity()));
        builder.setView(input);

        // Set up the buttons
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String quantityString = input.getText().toString().trim();
                if (!quantityString.isEmpty()) {
                    int quantity = Integer.parseInt(quantityString);
                    item.setQuantity(quantity);
                    databaseHelper.updateItem(item);
                    adapter.notifyDataSetChanged();
                    Toast.makeText(MainActivity.this, "Quantity updated successfully", Toast.LENGTH_SHORT).show();

                    // Send SMS with the updated quantity (only if quantity is less than 2)
                    if (hasSmsPermission && quantity < 2) {
                        sendSms(item.getName(), quantity);
                    } else if (quantity >= 2) {
                        Toast.makeText(MainActivity.this, "SMS not sent. Quantity is greater than or equal to 2", Toast.LENGTH_SHORT).show();
                    } else {
                        showSmsPermissionPrompt();
                    }

                    dialog.dismiss(); // Dismiss the dialog after updating the quantity
                } else {
                    Toast.makeText(MainActivity.this, "Please enter a quantity", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }


    private boolean checkSmsPermission() {
        int permissionStatus = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
        return permissionStatus == PackageManager.PERMISSION_GRANTED;
    }

    private void showSmsPermissionPrompt() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("SMS Permission");
        builder.setMessage("This app requires SMS permission to send quantity updates. Grant permission?");
        builder.setPositiveButton("Grant", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
            }
        });
        builder.setNegativeButton("Deny", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        });
        builder.show();
    }

    private void sendSms(String itemName, int quantity) {
        //SMS logic
        String message = "Item: " + itemName + "\nQuantity: " + quantity;
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage("+1234567890", null, message, null, null);
        Toast.makeText(MainActivity.this, "SMS sent", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                hasSmsPermission = true;
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                hasSmsPermission = false;
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

}
