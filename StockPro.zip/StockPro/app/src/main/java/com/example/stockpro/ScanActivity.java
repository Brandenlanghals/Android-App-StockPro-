package com.example.stockpro;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class ScanActivity extends Activity {
    private TextView textViewTitle;
    private SurfaceView surfaceView;
    private LinearLayout contentLayout;
    private LinearLayout incrementDecrementLayout;
    private Button buttonDecrement;
    private EditText editTextQuantity;
    private Button buttonIncrement;
    private Button buttonScan;
    private LinearLayout footerMenu;
    private Button buttonHome;
    private Button buttonScanFooter;
    private Button buttonLogout;

    private int quantity = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);

        textViewTitle = findViewById(R.id.textViewTitle);
        surfaceView = findViewById(R.id.surfaceView);
        contentLayout = findViewById(R.id.contentLayout);
        incrementDecrementLayout = findViewById(R.id.incrementDecrementLayout);
        buttonDecrement = findViewById(R.id.buttonDecrement);
        editTextQuantity = findViewById(R.id.editTextQuantity);
        buttonIncrement = findViewById(R.id.buttonIncrement);
        buttonScan = findViewById(R.id.buttonScan);
        footerMenu = findViewById(R.id.footerMenu);
        buttonHome = findViewById(R.id.buttonHome);
        buttonScanFooter = findViewById(R.id.buttonScanFooter);
        buttonLogout = findViewById(R.id.buttonLogout);

        buttonDecrement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decrementQuantity();
            }
        });

        buttonIncrement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incrementQuantity();
            }
        });

        buttonScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scanItem();
            }
        });

        buttonHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToHome();
            }
        });

        buttonScanFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToScan();
            }
        });

        buttonLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logout();
            }
        });
    }

    private void decrementQuantity() {
        if (quantity > 0) {
            quantity--;
            editTextQuantity.setText(String.valueOf(quantity));
        }
    }

    private void incrementQuantity() {
        quantity++;
        editTextQuantity.setText(String.valueOf(quantity));
    }

    private void scanItem() {
        // Add your code here to perform item scanning logic
        // This method will be called when the Scan button is clicked
        Toast.makeText(this, "Scanning item...", Toast.LENGTH_SHORT).show();
    }

    private void goToHome() {
        // Add your code here to navigate to the Home screen
        // This method will be called when the Home button is clicked
        Toast.makeText(this, "Going to Home...", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(ScanActivity.this, MainActivity.class);
        startActivity(intent);
    }

    private void goToScan() {
        // Add your code here to navigate to the Scan screen
        // This method will be called when the Scan button in the footer menu is clicked
        Toast.makeText(this, "Going to Scan...", Toast.LENGTH_SHORT).show();
    }

    private void logout() {
        // Add your code here to perform logout functionality
        // This method will be called when the Logout button is clicked
        Toast.makeText(this, "Logging out...", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(ScanActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}
