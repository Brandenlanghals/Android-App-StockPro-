package com.example.stockpro;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 3;

    private static final String TABLE_ITEMS = "items";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_QUANTITY = "quantity";
    public static final String COLUMN_USERNAME = "username";

    public static final String TABLE_USERS = "users";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_PHONE_NUMBER = "phone_number";

    private Context context;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableItems = "CREATE TABLE " + TABLE_ITEMS +
                "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT, " +
                COLUMN_QUANTITY + " INTEGER, " +
                COLUMN_USERNAME + " TEXT" +
                ")";
        db.execSQL(createTableItems);

        String createTableUsers = "CREATE TABLE " + TABLE_USERS +
                "(" +
                COLUMN_USERNAME + " TEXT PRIMARY KEY, " +
                COLUMN_PASSWORD + " TEXT, " +
                COLUMN_PHONE_NUMBER + " TEXT" +
                ")";
        db.execSQL(createTableUsers);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    public long insertItem(Item item) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, item.getName());
        values.put(COLUMN_QUANTITY, item.getQuantity());
        values.put(COLUMN_USERNAME, item.getUsername());
        long itemId = db.insert(TABLE_ITEMS, null, values);
        db.close();
        return itemId;
    }

    public List<Item> getAllItems(String searchQuery) {
        List<Item> itemList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_ITEMS;

        if (searchQuery != null && !searchQuery.isEmpty()) {
            selectQuery += " WHERE " + COLUMN_NAME + " LIKE '%" + searchQuery + "%'";
        }

        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            int idIndex = cursor.getColumnIndexOrThrow(COLUMN_ID);
            int nameIndex = cursor.getColumnIndexOrThrow(COLUMN_NAME);
            int quantityIndex = cursor.getColumnIndexOrThrow(COLUMN_QUANTITY);
            int usernameIndex = cursor.getColumnIndexOrThrow(COLUMN_USERNAME);

            do {
                int id = cursor.getInt(idIndex);
                String name = cursor.getString(nameIndex);
                int quantity = cursor.getInt(quantityIndex);
                String username = cursor.getString(usernameIndex);

                Item item = new Item(id, name, quantity, username);
                itemList.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        return itemList;
    }

    public void updateItem(Item item) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, item.getName());
        values.put(COLUMN_QUANTITY, item.getQuantity());

        if (item.getQuantity() < 2) {
            // Retrieve the user associated with the item
            User user = getUserByItemUsername(item.getUsername());

            if (user != null && user.getPhoneNumber() != null) {
                // Prompt for SMS messaging
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Low Quantity Alert")
                        .setMessage("The item quantity is low. Send SMS notification?")
                        .setPositiveButton("Send", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // Code to send SMS notification
                                Toast.makeText(context, "SMS notification sent", Toast.LENGTH_SHORT).show();
                                dialog.dismiss();
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });

                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        }

        db.update(TABLE_ITEMS, values, COLUMN_ID + " = ?", new String[]{String.valueOf(item.getId())});
        db.close();
    }

    public void deleteItem(int id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_ITEMS, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
    }

    public User getUser(String username) {
        SQLiteDatabase db = getReadableDatabase();
        String[] projection = {COLUMN_USERNAME, COLUMN_PASSWORD, COLUMN_PHONE_NUMBER};
        String selection = COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {username};
        Cursor cursor = db.query(TABLE_USERS, projection, selection, selectionArgs, null, null, null);
        User user = null;

        if (cursor != null && cursor.moveToFirst()) {
            int passwordIndex = cursor.getColumnIndex(COLUMN_PASSWORD);
            int phoneNumberIndex = cursor.getColumnIndex(COLUMN_PHONE_NUMBER);
            String password = cursor.getString(passwordIndex);
            String phoneNumber = null;

            boolean enableSMS = hasEnabledSMS(username);
            if (enableSMS) {
                phoneNumber = cursor.getString(phoneNumberIndex);
            }

            user = new User(username, password, phoneNumber);
        }

        cursor.close();
        db.close();

        return user;
    }

    public long insertUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, user.getUsername());
        values.put(COLUMN_PASSWORD, user.getPassword());
        values.put(COLUMN_PHONE_NUMBER, user.getPhoneNumber());
        long userId = db.insert(TABLE_USERS, null, values);
        db.close();
        return userId;
    }

    public List<Item> searchItemsByName(String searchQuery) {
        List<Item> itemList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_ITEMS + " WHERE " + COLUMN_NAME + " LIKE '%" + searchQuery + "%'";

        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            int idIndex = cursor.getColumnIndexOrThrow(COLUMN_ID);
            int nameIndex = cursor.getColumnIndexOrThrow(COLUMN_NAME);
            int quantityIndex = cursor.getColumnIndexOrThrow(COLUMN_QUANTITY);
            int usernameIndex = cursor.getColumnIndexOrThrow(COLUMN_USERNAME);

            do {
                int id = cursor.getInt(idIndex);
                String name = cursor.getString(nameIndex);
                int quantity = cursor.getInt(quantityIndex);
                String username = cursor.getString(usernameIndex);

                Item item = new Item(id, name, quantity, username);
                itemList.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        return itemList;
    }

    public User getUserByItemUsername(String itemUsername) {
        if (itemUsername == null) {
            return null;
        }
        SQLiteDatabase db = getReadableDatabase();
        String[] projection = {COLUMN_USERNAME, COLUMN_PASSWORD, COLUMN_PHONE_NUMBER};
        String selection = COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {itemUsername};
        Cursor cursor = db.query(TABLE_USERS, projection, selection, selectionArgs, null, null, null);
        User user = null;

        if (cursor != null && cursor.moveToFirst()) {
            int passwordIndex = cursor.getColumnIndex(COLUMN_PASSWORD);
            int phoneNumberIndex = cursor.getColumnIndex(COLUMN_PHONE_NUMBER);
            String password = cursor.getString(passwordIndex);
            String phoneNumber = null;

            boolean enableSMS = hasEnabledSMS(itemUsername);
            if (enableSMS) {
                phoneNumber = cursor.getString(phoneNumberIndex);
            }

            user = new User(itemUsername, password, phoneNumber);
        }

        cursor.close();
        db.close();

        return user;
    }

    public boolean hasEnabledSMS(String username) {
        SQLiteDatabase db = getReadableDatabase();
        String[] projection = {COLUMN_PHONE_NUMBER};
        String selection = COLUMN_USERNAME + " = ? AND " + COLUMN_PHONE_NUMBER + " IS NOT NULL";
        String[] selectionArgs = {username};
        Cursor cursor = db.query(TABLE_USERS, projection, selection, selectionArgs, null, null, null);
        boolean enableSMS = cursor != null && cursor.moveToFirst();
        cursor.close();
        db.close();
        return enableSMS;
    }
}
